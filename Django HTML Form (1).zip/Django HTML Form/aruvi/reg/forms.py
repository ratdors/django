from django import forms
from .models import Application
#Creating a fomr
class info(forms.ModelForm):
    class Meta:
        model=Application
        fields=[
            'first_name',
            'last_name',
            'Degree',
            'stu_gender',
            'phone_num',
            'address',
        ]

