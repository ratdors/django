from django.db import models
# Create your models here.
class Application(models.Model):
    GENDER_CHOICES=[
        ('M','MALE'),
        ('F','FEMALE')
    ]
    first_name=models.CharField(max_length=50)
    last_name=models.CharField(max_length=20,blank=True)
    Degree=models.CharField(max_length=25)
    stu_gender=models.CharField(choices=GENDER_CHOICES,max_length=1)
    phone_num=models.CharField(max_length=12)
    address=models.TextField()