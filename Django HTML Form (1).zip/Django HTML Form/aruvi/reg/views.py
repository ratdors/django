from django.shortcuts import render
from .forms import info
# Create your views here.
def create_view(request):
    #dictionary for initial data with field names as keys
    context={}
    #add the dictionary during initialization
    form=info(request.POST or None)
    if form.is_valid():
        form.save()
    context['form']=form
    return render(request,"index.html",context)